﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

[CreateAssetMenu (menuName = "Runtime Sets/Team Runtime Set")]
public class TeamRuntimeSet : RuntimeSet<Team> {}
