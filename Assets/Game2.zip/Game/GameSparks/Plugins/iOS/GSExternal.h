//
//  GSExternal.h
//


#if __cplusplus
extern "C" {
#endif
    void GSGetProxySettings();
#if __cplusplus
}
#endif
