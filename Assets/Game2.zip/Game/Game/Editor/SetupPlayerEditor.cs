﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEditor;

[CustomEditor(typeof(PhotonPlayer))]
public class SetupPlayerEditor : Editor 
{
	public override void OnInspectorGUI()
	{
		DrawDefaultInspector();
        
        PhotonPlayer myScript = (PhotonPlayer)target;
        if(GUILayout.Button("Setup"))
        {
            myScript.Setup();
        }
	}
}
