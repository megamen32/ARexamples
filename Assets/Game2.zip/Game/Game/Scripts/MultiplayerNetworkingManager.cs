﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using GameSparks.Api.Responses;
using GameSparks.Core;
using GameSparks.Api.Messages;
using GameSparks.RT;
using Photon.Pun;
using Photon.Realtime;

public class MultiplayerNetworkingManager : MonoBehaviour 
{
	#region MultiplayerNetworkingManager Singleton
	private static MultiplayerNetworkingManager instance = null;
	public static MultiplayerNetworkingManager Instance(){
		if (instance != null) {
			return instance;
		} else {
			Debug.LogError ("GSM| GameSparksManager Not Initialized...");
		}
		return null;
	}
    
    void Awake() {
		instance = this; // if not, give it a reference to this class
		DontDestroyOnLoad(this.gameObject); // and make this object persistent as we load new scenes
	}
    #endregion

    #region RT Session
	/// <summary>Need the GameSparksRTUnity class to create a real-time session</summary>
	

	/// <summary>Local private variable so we can access the RTSessionInfo used to create this session</summary>
	private RTSessionInfo sessionInfo;	
    public RTSessionInfo GetSessionInfo(){ return sessionInfo; }
    #endregion

	#region Login & Registration
	//	We are using an adaptable login method so that it removes the need for an extra registration screen upon login.
	//	This lets the developer automatically create a new user even if the user hasn't registered yet. 

	public delegate void AuthCallback(AuthenticationResponse _authresp2);
	public delegate void RegCallback(RegistrationResponse _authResp);
	//	Using a callback to allow the lobby manager to update the user's ID and connection-status 
	//	only when we have received a valid response. The reason for the two callbacks is that 
	//	the RegistrationResponse and AuthenticationResponse are slightly different.

	

        public void Connect()
        {
            // we check if we are connected or not, we join if we are, else we initiate the connection to the server.
            if (PhotonNetwork.InLobby) 
            {
                // #Critical we need at this point to attempt joining a Random Room. If it fails, we'll get notified in OnPhotonRandomJoinFailed() and we'll create one.
                PhotonNetwork.JoinRandomRoom();
            } else
            {
                // #Critical, we must first and foremost connect to Photon Online Server.
                PhotonNetwork.ConnectUsingSettings();
            }
        }
        
		
	#endregion

    #region Matchmaking Request
	/// <summary>
    /// This will request a pvp match between as many players you have set in the match. Parameters are set by GameManager.
    /// </summary>
    public void SendMatchmakingRequest(string _matchShortCode, long _matchSkill, string _matchGroup) 
    {
        Debug.Log ("GSM| Attempting Matchmaking...");

        new GameSparks.Api.Requests.MatchmakingRequest ()
            .SetMatchShortCode (_matchShortCode) 
            .SetSkill (_matchSkill)
            .SetMatchGroup (_matchGroup) // set the match group (this is set by the CloudAnchorController during hosting a room)
            .Send ((response) => 
            {
                // Check for errors
                if(response.HasErrors)
                { 
                    Debug.LogError("GSM| MatchMakingRequest Error \n" + response.Errors.JSON);
                }
            });
    }
    #endregion


    #region Start New RT Session
	/// <summary>Create a new session by passing in the match details</summary>
	public void StartNewRTSession(RTSessionInfo _info)
	{
     Connect();
    }
    #endregion

    private void OnRTReady(bool _isReady) {
        if (_isReady) {
            
            Debug.Log ("GSM| RT Session Connected...");

            // When the real-time session has successfully been configured between the participants in the MatchFoundMessage, set up the game. 
            GameManager.Instance().StartGame();
        }
    }

    private void OnPlayerConnected(int _peerId)
    {
        Debug.Log ("GSM| Player Connected, " + _peerId);

        GameManager.Instance().OnOpponentConnected(_peerId);
    }
    
    private void OnPeerDisconnected(int _peerId)
    {
        Debug.Log ("GSM| Player Disconnected, " + _peerId);

        GameManager.Instance().OnOpponentDisconnected(_peerId);
    }

    private void OnPacketReceived(OperationCode _packet)
    {
      //  Debug.Log("GSM| Packet received from " + _packet.Sender + " for OpCode " + _packet.OpCode);

        switch (_packet.OpCode) 
        {
            // Op-code 1 refers to 
            case 1:
                break;
            // Op-code 2 refers to 
            case 2:
                GameManager.Instance().UpdateOpponentCameraMovement(_packet);
                break;
            // Op-code 3 refers to 
            case 3:
                GameManager.Instance().UpdateOpponentAbility(_packet);
                break;
            case 4:
                GameManager.Instance().UpdateOpponentShield(_packet);
                break;
            case 5:
                GameManager.Instance().UpdateOpponentSpectatorMode(_packet);
                break;
            case 6:
                GameManager.Instance().UpdateOpponentProjectile(_packet);
                break;
        }
    }
}



public class RTSessionInfo 
{	
    private string hostURL;
    public string GetHostURL(){    return this.hostURL;    }
    private string acccessToken;
    public string GetAccessToken(){    return this.acccessToken;    }
    private int portID;
    public int GetPortID(){    return this.portID;    }
    private string matchID;
    public string GetMatchID(){    return this.matchID;    }

    private List<RTPlayer> playerList = new List<RTPlayer> ();
    public List<RTPlayer> GetPlayerList(){
        return playerList;
    }

    /// <summary>
    /// Creates a new RTSession object which is held until a new RT session is created
    /// </summary>
    public RTSessionInfo (MatchFoundMessage _message)
    {
        portID = (int)_message.Port;
        hostURL = _message.Host;
        acccessToken = _message.AccessToken;
        matchID = _message.MatchId;

        // we loop through each participant and get their peerId and display name //
        foreach(MatchFoundMessage._Participant player in _message.Participants)
        {
            playerList.Add(new RTPlayer(player.DisplayName, player.Id, (int)player.PeerId));
        }
    }

    public void UpdateRTSessionInfo (MatchUpdatedMessage _message) 
    {
        // The MatchUpdatedMessage's participants list contains the most recent list of players in the match, so we can reset the list
        playerList = new List<RTPlayer> ();
        foreach(MatchUpdatedMessage._Participant player in _message.Participants)
        {
            playerList.Add(new RTPlayer(player.DisplayName, player.Id, (int)player.PeerId));
        }
    }

    public class RTPlayer
    {
        public RTPlayer(string _displayName, string _id, int _peerId){
            this.displayName = _displayName;
            this.id = _id;
            this.peerId = _peerId;
        }

        public string displayName;
        public string id;
        public int peerId;
        public bool isOnline;
    }
}
